package COMUN;

public interface itfProperty {

    public Object getPropertyV (String Propiedad);
}
