package COMUN;

public class clsConstantes {

    public static final String VIVIENDA_ID = "ID_VIVIENDA";
    public static final String VIVIENDA_CODIGO = "COD_VIVIENDA";
    public static final String VIVIENDA_PRECIO = "PRECIO";
    public static final String VIVIENDA_DESCRIPCION = "DESCRIPCION";
    public static final String VIVIENDA_HABITACIONES = "HABITACIONES";
    public static final String VIVIENDA_METROS = "METROS";
    public static final String VIVIENDA_METROS_TERRENO = "METROS_TERRENO";
}
