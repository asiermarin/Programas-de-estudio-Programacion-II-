
import LP.frmInmobiliaria;

/**
 * Clase donde comienza a ejecutarse el programa: Por un lado guarda la lista cada minuto y por otro lanza la ventana.
 * @author ALUMNO
 *
 */
public class clsMainInmobiliaria 
{

	public static void main(String[] args) 
	{

		frmInmobiliaria frame = new frmInmobiliaria();
		frame.setVisible(true);
		
	}

}
